# DIHWorld Enhanced Template Set

Updated: 2026-07-25

Current family authority: `/Users/hakeemsalaam/Development/DIH_BUILDS/DIH_FAMILIES/CURRENT_FAMILY_AUTHORITY.md`
User manual: `/Users/hakeemsalaam/Development/DIH_BUILDS/DIH_FAMILIES/DIHWorld_Audio_Complete_Manual_CURRENT.pdf`

These files are the customer-facing DIHWorld Audio template starters for website and launch-package use. Templates are routing and workflow starters only. They must not include case study results, client/session results, or back-office material.

Enhancement basis:

- Current ANKH family authority from `DIH_FAMILIES/CURRENT_FAMILY_AUTHORITY.md`.
- Smart Position placement classes.
- DIH engine canon: PHI/2 ceiling, protected Input/Mix/Output behavior, no hidden gain riding.
- User working practice: plugins are stackable and often interchangeable, but best in their home position; rarely use more than three active processors on a track or bus.

Key rule across the set:

Start buses and sends around -18 dB as a safe audition point, not a fixed operating target. In normal use, many DIH processors will feel optimal around -14 to -10 dB depending on source, family, and FieldState. Some plugins operate cleanly at unity when the use case supports it; approve unity only after bypass/output matching and no clipping, ringing, harshness, or level jump. Use up to three active processors per track or bus. SESHAT may sit last on the print/master endpoint as observation only. Match final output to the project delivery specification; the templates do not impose fixed RMS, peak, or crest targets.

Current behavior carried by every template:

- ANUBIS may receive a named stereo host Sidechain bus; Key and Duck are separate choices.
- DEBO restores the iCloud canonical naming as nine updated programs; `VOCAL HOLD` remains the tonal anchor and `RED LINE WATCH` is the strongest factory stage at 4.2 dB Maximize.
- TRIPLER's repaired left/right voices are clean harmony lanes, not gain-reduced distortion workarounds.
- SESHAT `Full Observation` shows all panels; named views show only their relevant meter/panel.
- AU and DIH Drum Morpher are current Logic-visible instruments; Drum Morpher includes its restored factory programs.

Website starter set:

- Template 1: 01_Cascading_Bus_Template_enhanced.pdf
- Template 2: 02_7Bus_Template_enhanced.pdf
- Template 3: 03_Family_Affair_Template_enhanced.pdf
- Template 4: 04_Better_Buses_Template_enhanced.pdf
- Template 5: 05_Dynamics_Sidechain_Template_CURRENT.pdf

Back-office boundary:

- Case study results are not templates.
- Do not package back-office case study results into `User_Templates.zip` or `dihworld_templates.zip`.

Files:

- 01_Cascading_Bus_Template_enhanced.pdf
- 01_Cascading_Bus_Template_enhanced.md
- 02_7Bus_Template_enhanced.pdf
- 02_7Bus_Template_enhanced.md
- 03_Family_Affair_Template_enhanced.pdf
- 03_Family_Affair_Template_enhanced.md
- 04_Better_Buses_Template_enhanced.pdf
- 04_Better_Buses_Template_enhanced.md
- 05_Dynamics_Sidechain_Template_CURRENT.pdf
- 05_Dynamics_Sidechain_Template_CURRENT.md

Internal / back-office material is not included in this package.
