# DIHWorld Dynamics / Kick-Key / Duck Template

Current: 2026-07-31

## Session lanes

| Lane | Insert / Route | Starting action |
|---|---|---|
| Kick key | Send to named sidechain | Unity or pre-fader as needed |
| Bass target | ANUBIS | DUCK on; KEY optional |
| Music target | ANUBIS | Vocal sidechain; gentle Range |
| Reverb return | ANUBIS | KEY on from lead vocal |
| Drum parallel | DRUMKRUSHGLUE or DEBO | Blend below clean drums |
| Dynamics bus | OTIS → LOOKOUT | Shape then observe |
| Print endpoint | SESHAT | Observation only |

## Kick-to-bass starting card

- Route kick to ANUBIS Sidechain.
- Enable DUCK for rhythmic clearance.
- Enable KEY only if kick should drive gate detection.
- Start with shallow Range.
- Set fast Attack and tempo-aware Release.
- Check mono and bypass-match.

## Vocal-clearance starting card

- Insert ANUBIS on music or ambience target.
- Route lead vocal to Sidechain.
- Use DUCK for space around words.
- Use KEY on ambience returns that should open with the vocal.
- Keep Range gentle and Release natural.

## Dynamics stack options

| Goal | Suggested order | Note |
|---|---|---|
| Clean transient control | LOOKOUT → OTIS | Shape edge, then density |
| Pressure and body | OTIS → DEBO | Build gradually; Gain Match |
| Drum parallel impact | DRUMKRUSHGLUE → LOOKOUT | Blend beneath clean bus |
| Keyed ambience | ANUBIS → effect return | KEY only; no audible key |
| Rhythmic clearance | ANUBIS on target | DUCK from kick or vocal |

## Approval checklist

- Sidechain source is correct and audible to the detector.
- KEY and DUCK states match the intended behavior.
- Range is no deeper than required.
- Attack, Hold, and Release follow the groove.
- Bypass and output levels are matched.
- Mono remains stable.
- No clipping, static, harshness, or unintended level loss.
- No more than three active processors per lane unless deliberate.
