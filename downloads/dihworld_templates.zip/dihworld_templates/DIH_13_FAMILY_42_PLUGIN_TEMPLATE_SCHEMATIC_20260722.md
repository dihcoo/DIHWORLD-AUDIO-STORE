# DIHWorld Audio - 13 Family / 42 Plugin Template Schematic

Date: 2026-07-22  
Authority: `../CURRENT_FAMILY_AUTHORITY.md`  
Routing source: `../ROUTING_PLACEMENT_CANON.md`  
Smart Position source: `../SMART_POSITION/SMART_POSITION_CANON.md`

This schematic is the master planning page for the four customer-facing Logic templates:

1. Cascading Bus Template
2. 7 Main Bus Template
3. Family Affair Template
4. Better Buses Template

The goal is to show the whole DIHWorld system without forcing all 42 plugins to process at the same time. Every plugin appears in the template system, but each musical pass uses short active chains, bypassed alternates, scene reveals, and QC-only observation where appropriate.

## Core Template Law

- Every plugin keeps one primary family home.
- Every plugin card must carry dot-only placement indicators when full Primary, Secondary, Group/Bus, and Parallel wording would clutter the card.
- Full Primary, Secondary, Group/Bus, and Parallel wording belongs in the guide, legend, routing sheet, or expanded help view.
- Use no more than three active processors on a track or bus during a musical pass.
- Extra processors are marked `BYPASSED ALT`, `SCENE REVEAL`, or `QC ONLY`.
- SESHAT is observation only and may sit last on the print/master endpoint.
- ANKH remains final containment authority.
- Presets do not control protected Input, Output, Mix, Bypass/Power, or final ceiling/safety controls unless a product-specific canon explicitly allows it.

## 13 Family Map

| Family | Color | Count | Plugins | Primary use |
|---|---|---:|---|---|
| VOCAL_MIC_SOURCE | Gold | 6 | GOLD, SILVER, WPR, AEGIS_NOVA, TRIPLER, EchoLocate | Vocal/source tone, mic identity, source clarity |
| DYNAMICS_GUARD | Cyan | 4 | ANUBIS, OTIS, DEBO, LOOKOUT | Transient control, guard behavior, pressure, observation |
| BASS_LOW_END | Brown / low-gold | 4 | MARIANA, MONOLITH, DEPTH_BOOST_PRO, NTRPL | Foundation, low-end shape, sub/body |
| DRUM_INSTRUMENT | Red-orange | 3 | DIH_DRUM_MORPHER, BALLPARK, DRUMKRUSHGLUE | Drum identity, punch, impact, glue |
| COLOR_AMP_TAPE | Red-orange | 4 | APIS, PTAHTUBE, KHEPRI, SOVEREIGN | Color, amp, tape, material body |
| FIELD_TONE_BALANCE | White | 2 | AUSET, AUSAR | Tone/field balance and dispersal |
| DIMENSIONAL_IMPACT_MOVE | Purple | 3 | DEPTH_IMPACT_HYBRID_X, PARALLAX, NSR | Width, depth, motion, placement |
| FX_SPATIAL | Purple | 3 | NTRSTLLR, Cathedral, SacredVerb | Shared reverb, delay, chamber, space |
| HARMONICS_PITCH | Green | 3 | THOTH, TEHUTI, AU | Harmonic EQ, pitch guidance, sidechain harmonic shaping |
| CREATIVE_TRANSFORM | Red-orange | 3 | SLOTMACHINE, ARCHAEOLOGIST_X, SERQET | Creative transformation and special moments |
| MASTERING_CORE | Silver | 5 | ANKH, SPHYNX, MAAT, HORIZON_X, PLATINUM | Master preparation, balance, lift, containment |
| MASTER_FIELD | Silver | 1 | IMHOTEP | Macro field structure and finish |
| UTILITY_OBSERVATION | Green | 1 | SESHAT | Meter/advisor, observation only |

## Template 1 - Cascading Bus

Purpose: three deliberate parallel lanes feeding one clean collection point.

```text
SOURCE TRACKS
  Send -> EFFECTS BUS  [NTRSTLLR -> Cathedral -> SacredVerb]
  Send -> WIDTH BUS    [DEPTH_IMPACT_HYBRID_X -> PARALLAX -> NSR]
  Send -> COLOR BUS    [KHEPRI -> PTAHTUBE -> APIS]

EFFECTS + WIDTH + COLOR
  -> COLLECTION CHANNEL [summing only]
  -> PRINT / MASTER BUS
  -> Stereo Out
```

Highlighted families: `FX_SPATIAL`, `DIMENSIONAL_IMPACT_MOVE`, `COLOR_AMP_TAPE`, plus a print/master choice.

Substitution rule: SOVEREIGN may replace one COLOR slot; SERQET may replace PARALLAX for creative width. These substitutions replace a slot; they do not extend the chain.

## Template 2 - 7 Main Bus

Purpose: main multitrack routing template with seven working buses.

| Bus | Receives | Starter chain | Alternates |
|---|---|---|---|
| DRUMS | Kick, snare, rooms, percussion | ANUBIS -> DIH_DRUM_MORPHER -> BALLPARK | DRUMKRUSHGLUE replaces a slot for glue/impact |
| BASS | Bass DI, sub, low instruments | MARIANA -> NTRPL -> MONOLITH | DEPTH_BOOST_PRO replaces MONOLITH for definition |
| VOCAL | Lead, BG, harmony | GOLD -> AEGIS_NOVA -> SILVER | WPR, TRIPLER, EchoLocate replace source-tone slots |
| INSTRUMENT | Guitars, keys, piano, synths | KHEPRI -> PTAHTUBE -> APIS | THOTH or TEHUTI replaces a slot when harmonic pitch is the problem |
| EFFECTS | FX returns and spatial sends | NTRSTLLR -> Cathedral -> SacredVerb | Keep PARALLAX on WIDTH if WIDTH exists |
| COLOR | Parallel tone sends | KHEPRI -> PTAHTUBE -> APIS | SOVEREIGN replaces one slot for stronger color authority |
| DYNAMICS | Parallel dynamics send | OTIS -> DEBO -> LOOKOUT | ANUBIS or DRUMKRUSHGLUE can move in when the source requires it |

## Template 3 - Family Affair

Purpose: one-session demo where all 42 plugins appear, but the demo moves by family scenes.

| Timeline | Reveal | Families shown |
|---|---|---|
| Bars 1-16 | Raw source | No DIH processing |
| Bars 17-32 | Rhythm foundation | DRUM_INSTRUMENT, BASS_LOW_END, selected DYNAMICS_GUARD |
| Bars 33-48 | Vocal/source and music bed | VOCAL_MIC_SOURCE, COLOR_AMP_TAPE, HARMONICS_PITCH |
| Bars 49-64 | Space and movement | FX_SPATIAL, DIMENSIONAL_IMPACT_MOVE |
| Bars 65-80 | Color and creative moment | COLOR_AMP_TAPE, CREATIVE_TRANSFORM, FIELD_TONE_BALANCE |
| Bars 81-96 | Master clean chain | MASTERING_CORE, MASTER_FIELD, UTILITY_OBSERVATION |
| Bars 97-112 | Print reveal and bypass match | HORIZON_X or PLATINUM alternate, ANKH containment, SESHAT confirmation |

Coverage rule: Every plugin appears at least once as active, bypassed alternate, scene reveal, or QC-only observation.

## Template 4 - Better Buses

Purpose: practical customer-safe Logic layout with descriptive bus names and cleaner handoff.

```text
SOURCE TRACKS
  -> DRUM BUS
  -> BASS BUS
  -> LEAD VOCAL BUS
  -> BG VOCAL BUS
  -> INSTRUMENT BUS
  -> optional sends: FX BUS, COLOR BUS, WIDTH BUS, DYNAMICS BUS

FAMILY BUSES
  -> PRINT / MASTER BUS
  -> Stereo Out
```

| Bus | Starter chain | Best use |
|---|---|---|
| LEAD VOCAL BUS | GOLD -> AEGIS_NOVA -> SILVER | Lead vocal source tone and protection |
| BG VOCAL BUS | GOLD -> TRIPLER -> EchoLocate | Stacks, doubles, localization |
| DRUM BUS | DIH_DRUM_MORPHER -> BALLPARK -> DRUMKRUSHGLUE | Drum identity, punch, glue |
| BASS BUS | MARIANA -> NTRPL -> MONOLITH | Low-end foundation |
| INSTRUMENT BUS | KHEPRI -> PTAHTUBE -> APIS | Music bed tone and harmonic color |
| FX BUS | NTRSTLLR -> Cathedral -> SacredVerb | Shared spatial identity |
| COLOR BUS | KHEPRI -> PTAHTUBE -> APIS | Parallel tone and bus color |
| WIDTH BUS | DEPTH_IMPACT_HYBRID_X -> PARALLAX -> NSR | Width, placement, front/back movement |
| DYNAMICS BUS | ANUBIS -> OTIS -> DEBO | Guard, pressure, movement |

## Visual Mock-Up Rules

Each template image should show:

- A DAW-style lane header for the template type.
- Family color strips for quick scanning.
- Active plugins as bright chips.
- Bypassed alternates as dim chips.
- QC-only tools, especially SESHAT, marked as observation.
- Dot protocol on each highlighted family or bus: bright equals proper/current placement, dim equals available/inactive, slow pulse equals suggested redirect, flashing equals risk.
- No long placement dialog over template lane art or plugin imagery.
- No more than three active processors in one lane.

## First Image Set

Create four images:

1. `01_cascading_bus_schematic` - three parallel lanes into collection and print.
2. `02_7bus_schematic` - seven buses with family chain chips.
3. `03_family_affair_13_family_schematic` - all 13 families and 42 plugin chips arranged by scene.
4. `04_better_buses_schematic` - practical customer bus map with Better Buses highlighted.

These images can be used on the website, PDF handoff, or Logic template instructions. They are planning images, not screenshots of a finished Logic project.

## Current Mock-Up Draft

Conversation mock-up source:

`/Users/hakeemsalaam/.codex/visualizations/2026/06/30/019f1667-22ca-7921-8674-7c2fa62ad477/dih-13-family-template-map.html`

Use this as the first visual board for review. Once approved, split it into the four separate template images listed above and drop the approved versions beside this schematic.
