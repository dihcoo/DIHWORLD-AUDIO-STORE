# DIHWorld Audio — 42 Plugin Placement Schematic

Date: 2026-07-25
Authority: `../CURRENT_FAMILY_AUTHORITY.md`
Routing source: `../ROUTING_PLACEMENT_CANON.md`
Smart Position source: `../SMART_POSITION/SMART_POSITION_CANON.md` and `../SMART_POSITION/SMART_POSITION_MANIFEST.json`
Companion planning page: `DIH_13_FAMILY_42_PLUGIN_TEMPLATE_SCHEMATIC_20260722.md`

## Purpose

`ROUTING_PLACEMENT_CANON.md` gives every family a placement summary, but only fully works out the per-plugin Primary/Secondary/Group-Bus/Parallel rail for two families (FX_SPATIAL and DIMENSIONAL_IMPACT_MOVE). This schematic extends that exact same per-plugin rail to all 13 families and all 42 plugins, so every plugin page, quick-start card, and routing sheet has one place to pull its placement row from.

Nothing here overrides the authority chain above. If a plugin's row conflicts with `CURRENT_FAMILY_AUTHORITY.md` or `SMART_POSITION_CANON.md`, those files win.

Current implementation note: ANUBIS accepts a named stereo sidechain with independent Key/Duck functions; DEBO uses nine updated programs with restored iCloud canonical naming; TRIPLER uses the repaired clean left/right harmony path and corrected return level; SESHAT named views hide unrelated panels; AU and DIH Drum Morpher are current registered instruments, with Drum Morpher factory programs restored.

## How to read a row

| Field | Meaning |
|---|---|
| Smart Position class | The machine-readable placement class from `SMART_POSITION_MANIFEST.json` (INSERT_SAFE, BUS_PREFERRED, MIX_BUS, MASTER_FIELD, OBSERVATION, CREATIVE_TRANSFORM, LOW_END_SOURCE). |
| Primary | First recommended placement for normal use. |
| Secondary | Next useful position when the session calls for it. |
| Group/Bus | Exact stem, aux, return, or master lane. |
| Parallel | Yes / Optional / No, with guidance. |
| Note | One-line user-facing placement note, including any secondary dot tag. |

Dots on the plugin face are the compact version of this table (bright = confirmed role, dim = available, slow pulse = better placement suggested, flashing = risk detected). This table is the long-form source those dots are summarizing.

---

## VOCAL_MIC_SOURCE — Gold — 6 plugins

Family default: Track Insert / Vocal Bus / Lead or Background Vocal Bus / usually no parallel unless noted.
Lead Vocal Bus chain: `GOLD -> AEGIS_NOVA -> SILVER`. Background Vocal Bus chain: `GOLD -> TRIPLER -> EchoLocate`.

| Plugin | Smart Position | Primary | Secondary | Group/Bus | Parallel | Note |
|---|---|---|---|---|---|---|
| GOLD | INSERT_SAFE | Track Insert | Vocal Bus (opens both chains) | Lead Vocal Bus / Background Vocal Bus | Usually no | Source/vocal color; opens both the Lead and Background Vocal Bus chains; secondary silver Mastering Support dot. |
| AEGIS_NOVA | INSERT_SAFE | Track Insert | Vocal Bus (chain middle) | Lead Vocal Bus (middle slot) | Usually no | Vocal/source protection and tone; sits between GOLD and SILVER. |
| SILVER | INSERT_SAFE | Track Insert | Vocal Bus (chain end) / Mastering Support | Lead Vocal Bus (chain-end) | Usually no | Closes the Lead Vocal Bus chain; secondary silver Mastering Support dot. |
| TRIPLER | INSERT_SAFE | Track Insert | Vocal Bus (chain middle) | Background Vocal Bus (middle slot) | Yes, for stacks/doubles | Mic-array enhancement for stacks and doubles; secondary Width tag. |
| EchoLocate | INSERT_SAFE | Track Insert | Vocal Bus (chain end) | Background Vocal Bus (chain-end) | Usually no | Source localization; closes the Background Vocal Bus chain. |
| WPR | INSERT_SAFE | Track Insert | Vocal Bus | Lead/Background Vocal Bus (substitution slot) | Optional, for width | Ribbon mic source shaping; secondary Width tag. |

---

## DYNAMICS_GUARD — Cyan — 4 plugins

Family default: Track Insert or Group Bus by product / Dynamics Bus / Vocal-Dynamics Bus / product-specific parallel.
Dynamics Bus chain: `ANUBIS -> OTIS -> DEBO`.

| Plugin | Smart Position | Primary | Secondary | Group/Bus | Parallel | Note |
|---|---|---|---|---|---|---|
| ANUBIS | INSERT_SAFE | Track Insert | Dynamics Bus (chain start) | Dynamics Bus (first slot) | No | Gate/expander plus RMS guard; opens the Dynamics Bus chain. |
| OTIS | INSERT_SAFE | Track Insert | Dynamics Bus (chain middle) / Mastering Support | Dynamics Bus (middle slot) | No | Dynamics support with secondary silver Mastering Support dot. |
| DEBO | INSERT_SAFE | Track Insert | Dynamics Bus (chain end) | Dynamics Bus (chain-end) | Yes, pressure-activated | Only DYNAMICS_GUARD plugin with an explicit parallel-impact return. |
| LOOKOUT | INSERT_SAFE | Track Insert | Dynamics Bus (chain end) / Observation / Mastering Support | Dynamics Bus (chain-end) | No | Dual-envelope transient/sustain shaper: Attack/Sustain directly move transient and sustain gain up to +/-18dB. Eye of Heru advisory guidance and silver Mastering Support are secondary dots, not the primary function. |

---

## BASS_LOW_END — Brown/low-gold — 4 plugins

Family default: Track Insert / Bass Bus / Bass-Low-End Bus / usually no, parallel only for controlled sub reinforcement.
Bass Bus chain: `MARIANA -> NTRPL -> MONOLITH`.

| Plugin | Smart Position | Primary | Secondary | Group/Bus | Parallel | Note |
|---|---|---|---|---|---|---|
| MARIANA | LOW_END_SOURCE | Track Insert | Bass Bus (chain start) | Bass Bus (first slot) | No | Sub/low-end field foundation; opens the Bass Bus chain. |
| NTRPL | LOW_END_SOURCE | Track Insert | Bass Bus (chain middle) | Bass Bus (middle slot) | No | Phi Harmonic Rewriter reclassified into the bass family; sits between MARIANA and MONOLITH. |
| MONOLITH | LOW_END_SOURCE | Track Insert | Bass Bus (chain end) | Bass Bus (last slot) | No | Low-end mass/weight; closes the Bass Bus chain. |
| DEPTH_BOOST_PRO | LOW_END_SOURCE | Track Insert | Bass Bus (definition alternate) / Spatial Gain Support | Bass Bus (replaces MONOLITH slot) | Optional, controlled sub reinforcement | Replaces MONOLITH in the 7-Bus template when extra low-end definition is needed. Secondarily a spatial gain plugin: a dedicated Spatial Gain control (0dB to -12dB) sits after its delay-based depth/width field, not a generic output trim; blue secondary dot. |

---

## DRUM_INSTRUMENT — Red-orange — 3 plugins

Family default: Instrument Track or Drum Bus by product / Track Insert-Drum Bus / Drum Bus / product-specific parallel.
Drum Bus chain: `DIH_DRUM_MORPHER -> BALLPARK -> DRUMKRUSHGLUE`.

| Plugin | Smart Position | Primary | Secondary | Group/Bus | Parallel | Note |
|---|---|---|---|---|---|---|
| DIH_DRUM_MORPHER | CREATIVE_TRANSFORM | Instrument Track | Drum Bus (chain start) | Drum Bus (first slot) | No, source instrument | Instrument-level drum generator/morpher; opens the Drum Bus chain. |
| BALLPARK | CREATIVE_TRANSFORM | Track Insert | Drum Bus (chain middle) | Drum Bus (middle slot) | Optional, bus energy | Supports bus energy in the middle Drum Bus slot. |
| DRUMKRUSHGLUE | BUS_PREFERRED | Drum Bus | Track Insert / Dynamics Guard support | Drum Bus (chain-end) or Parallel Drum-Impact Return | Yes | Primary DRUM_INSTRUMENT with secondary cyan Dynamics Guard Support dot for transient, pressure, and cohesion work. |

---

## COLOR_AMP_TAPE — Red-orange — 4 plugins

Family default: Track Insert / Color Bus / Music-Instrument or Parallel Color Bus / yes for color blend, no hidden level lift.
Instrument/Color Bus chain: `KHEPRI -> PTAHTUBE -> APIS`.

| Plugin | Smart Position | Primary | Secondary | Group/Bus | Parallel | Note |
|---|---|---|---|---|---|---|
| KHEPRI | INSERT_SAFE | Track Insert | Color Bus (chain start) / Mastering Support | Music/Instrument Bus or Parallel Color Bus (first slot) | Yes, color blend | Default Mix at 1/Phi per canon; secondary silver Mastering Support dot; opens the Color Bus chain. |
| PTAHTUBE | INSERT_SAFE | Track Insert | Color Bus (chain middle) | Music/Instrument Bus or Parallel Color Bus (middle slot) | Yes, color blend | Tube color stage; check vocal clarity when inserted on vocal sources. |
| APIS | INSERT_SAFE | Track Insert | Color Bus (chain end) | Music/Instrument Bus or Parallel Color Bus (last slot) | Yes, color blend | Amp/color source tone; closes the Instrument/Color Bus chain. |
| SOVEREIGN | MIX_BUS | Mix Bus | Color Bus alternate / Mastering Support | Parallel Color Bus (replaces one KHEPRI/PTAHTUBE/APIS slot) | Yes | Stronger color and bus authority; replaces a Color Bus slot when needed; secondary silver Mastering Support dot. |

---

## FIELD_TONE_BALANCE — White — 2 plugins

Family default: Group Bus / Track Insert when subtle / Music-Field Tone Bus / optional, especially for dispersal.

| Plugin | Smart Position | Primary | Secondary | Group/Bus | Parallel | Note |
|---|---|---|---|---|---|---|
| AUSET | BUS_PREFERRED | Group Bus | Track Insert (subtle, vocal-first use) | Music/Field Tone Bus | Optional, dispersal field | Tone balance and dispersal field; also carries a secondary Vocal First tag for subtle direct-insert use. |
| AUSAR | BUS_PREFERRED | Group Bus | Track Insert when subtle | Music/Field Tone Bus | Optional | Field/tone balance counterpart to AUSET. |

---

## DIMENSIONAL_IMPACT_MOVE — Purple — 3 plugins

Family default: Track Insert or Width Bus by product / Aux Return / Width-Depth Bus / yes for PARALLAX and NSR.
Width/Depth Bus chain: `DEPTH_IMPACT_HYBRID_X -> PARALLAX -> NSR`.

| Plugin | Smart Position | Primary | Secondary | Group/Bus | Parallel | Note |
|---|---|---|---|---|---|---|
| DEPTH_IMPACT_HYBRID_X | INSERT_SAFE | Track Insert | Width/Depth Bus | Width/Depth Bus | Optional | Spectral clarity, harmonic depth, and hybrid spatial field; can sit on a source or shape the bus. |
| PARALLAX | BUS_PREFERRED | Group Bus | Aux Return | Width/Depth Bus | Yes | Bus-preferred dimensional placement. Default Mix belongs at 1/Phi unless product canon changes. |
| NSR | BUS_PREFERRED | Aux Return | Group Bus | Width/Depth or Parallel Spatial Bus | Yes | Phi-based spatial delay with motion, microphase, and flange. Default Mix at 1/Phi. |

Reused verbatim from `ROUTING_PLACEMENT_CANON.md` — this is the already-authoritative source table for this family.

---

## FX_SPATIAL — Purple — 3 plugins

Family default: Aux Return / Group Bus / Parallel Spatial Bus / yes, this is the main home for shared space.
Parallel Spatial Bus chain: `NTRSTLLR -> Cathedral -> SacredVerb`.

| Plugin | Smart Position | Primary | Secondary | Group/Bus | Parallel | Note |
|---|---|---|---|---|---|---|
| NTRSTLLR | BUS_PREFERRED | Aux Return | Source Insert | Parallel Spatial Bus | Yes | Phi delay/nebula/wormhole space. Use as a shared return first; insert only when the source needs its own moving delay field. |
| Cathedral | BUS_PREFERRED | Aux Return | Group Bus | Parallel Spatial Bus | Yes | Flagship room/architecture space. Best as a shared space return or group-space bus. |
| SacredVerb | BUS_PREFERRED | Aux Return | Group Bus | Parallel Spatial Bus | Yes | Sacred/chamber reverb. Best as a shared reverb return; keep Solfeggio lanes as musical triggers, not gain controls. |

Reused verbatim from `ROUTING_PLACEMENT_CANON.md` — this is the already-authoritative source table for this family.

---

## HARMONICS_PITCH — Green — 3 plugins

Family default: Track Insert / Bus analysis-tone / Harmonics-Pitch lane / usually no unless product-specific mode says so.

| Plugin | Smart Position | Primary | Secondary | Group/Bus | Parallel | Note |
|---|---|---|---|---|---|---|
| THOTH | INSERT_SAFE | Track Insert | Bus analysis/tone | Harmonics/Pitch lane (Instrument Bus alternate) | No, unless product mode states otherwise | Harmonic EQ and pitch guidance; alternates into the Instrument Bus when harmonic pitch is the specific problem. |
| TEHUTI | INSERT_SAFE | Track Insert | Bus analysis/tone | Harmonics/Pitch lane | No | Harmonic EQ and pitch guidance companion to THOTH. |
| AU | INSERT_SAFE | Track Insert | Bus analysis/tone | Harmonics/Pitch lane | No | Sidechain harmonic shaping utility. |

---

## CREATIVE_TRANSFORM — Red-orange — 3 plugins

Family default: Track Insert / Parallel Creative Bus / Creative Transform Bus / yes for creative blend, not for transparent correction.

| Plugin | Smart Position | Primary | Secondary | Group/Bus | Parallel | Note |
|---|---|---|---|---|---|---|
| SLOTMACHINE | CREATIVE_TRANSFORM | Track Insert | Parallel Creative Bus | Creative Transform Bus | Yes, creative blend | Intentional character transform, not a transparency tool. |
| ARCHAEOLOGIST_X | CREATIVE_TRANSFORM | Track Insert | Parallel Creative Bus | Creative Transform Bus | Yes, creative blend | Creative recovery/excavation processing for special moments. |
| SERQET | CREATIVE_TRANSFORM | Track Insert | Parallel Creative Bus / Width alternate | Creative Transform Bus, or Width/Depth Bus as a PARALLAX substitute | Yes | Can replace PARALLAX for creative width per the Cascading Bus substitution rule; secondary Width tag. |

---

## MASTERING_CORE — Silver — 5 plugins

Family default: Mix Bus / Master Field / Master Bus / no, unless a documented parallel mastering workflow exists.
Clean chain: `SPHYNX -> MAAT -> ANKH -> SESHAT`. Loud chain: `SPHYNX -> HORIZON_X -> ANKH -> SESHAT`. Authority chain: `PLATINUM -> IMHOTEP -> ANKH -> SESHAT`.

| Plugin | Smart Position | Primary | Secondary | Group/Bus | Parallel | Note |
|---|---|---|---|---|---|---|
| SPHYNX | MIX_BUS | Mix Bus | Master Field | Master Bus (chain-start, clean and loud chains) | No | Prepares material before field/finalization; opens both the clean and loud master chains. |
| MAAT | MIX_BUS | Mix Bus | Observation / Master Field | Master Bus (clean-chain middle slot) | No | Balance/justice stage with secondary green Observation dot; middle of the clean master chain. |
| HORIZON_X | MIX_BUS | Mix Bus | Master Field | Master Bus (loud-chain middle slot, MAAT alternate) | No | Controlled-lift finalizer; replaces MAAT in the loud master chain. |
| PLATINUM | MIX_BUS | Mix Bus | Color/Amp/Tape Support (red-orange) | Master Bus (authority-chain start) | No | Primary MASTERING_CORE with secondary red-orange Color/Amp/Tape Support for master-bus body; opens the authority chain. |
| ANKH | MASTER_FIELD | Master Field | Mix Bus | Master Bus (chain-end of every master chain) | No | Final containment authority; sits at the end of every master chain, immediately before SESHAT. |

---

## MASTER_FIELD — Silver — 1 plugin

| Plugin | Smart Position | Primary | Secondary | Group/Bus | Parallel | Note |
|---|---|---|---|---|---|---|
| IMHOTEP | MASTER_FIELD | Master Field | Mix Bus | Master Bus (authority-chain middle slot, between PLATINUM and ANKH) | No | Macro master-field structure and finish stage in the authority chain. |

---

## UTILITY_OBSERVATION — Green — 1 plugin

| Plugin | Smart Position | Primary | Secondary | Group/Bus | Parallel | Note |
|---|---|---|---|---|---|---|
| SESHAT | OBSERVATION | Observation | Print/Analysis endpoint | Print/Master endpoint (last in every master chain) | No | Translates phi score into guidance; always last on the print/master endpoint; not counted toward the 3-active-processor limit. |

---

## Full 42-Plugin Index

Quick lookup, alphabetical within family order from `CURRENT_FAMILY_AUTHORITY.md`.

| # | Plugin | Family | Color | Smart Position |
|---:|---|---|---|---|
| 1 | GOLD | VOCAL_MIC_SOURCE | Gold | INSERT_SAFE |
| 2 | SILVER | VOCAL_MIC_SOURCE | Gold | INSERT_SAFE |
| 3 | WPR | VOCAL_MIC_SOURCE | Gold | INSERT_SAFE |
| 4 | AEGIS_NOVA | VOCAL_MIC_SOURCE | Gold | INSERT_SAFE |
| 5 | TRIPLER | VOCAL_MIC_SOURCE | Gold | INSERT_SAFE |
| 6 | EchoLocate | VOCAL_MIC_SOURCE | Gold | INSERT_SAFE |
| 7 | ANUBIS | DYNAMICS_GUARD | Cyan | INSERT_SAFE |
| 8 | OTIS | DYNAMICS_GUARD | Cyan | INSERT_SAFE |
| 9 | DEBO | DYNAMICS_GUARD | Cyan | INSERT_SAFE |
| 10 | LOOKOUT | DYNAMICS_GUARD | Cyan | INSERT_SAFE |
| 11 | MARIANA | BASS_LOW_END | Brown/low-gold | LOW_END_SOURCE |
| 12 | MONOLITH | BASS_LOW_END | Brown/low-gold | LOW_END_SOURCE |
| 13 | DEPTH_BOOST_PRO | BASS_LOW_END | Brown/low-gold | LOW_END_SOURCE |
| 14 | NTRPL | BASS_LOW_END | Brown/low-gold | LOW_END_SOURCE |
| 15 | DIH_DRUM_MORPHER | DRUM_INSTRUMENT | Red-orange | CREATIVE_TRANSFORM |
| 16 | BALLPARK | DRUM_INSTRUMENT | Red-orange | CREATIVE_TRANSFORM |
| 17 | DRUMKRUSHGLUE | DRUM_INSTRUMENT | Red-orange | BUS_PREFERRED |
| 18 | APIS | COLOR_AMP_TAPE | Red-orange | INSERT_SAFE |
| 19 | PTAHTUBE | COLOR_AMP_TAPE | Red-orange | INSERT_SAFE |
| 20 | KHEPRI | COLOR_AMP_TAPE | Red-orange | INSERT_SAFE |
| 21 | SOVEREIGN | COLOR_AMP_TAPE | Red-orange | MIX_BUS |
| 22 | AUSET | FIELD_TONE_BALANCE | White | BUS_PREFERRED |
| 23 | AUSAR | FIELD_TONE_BALANCE | White | BUS_PREFERRED |
| 24 | DEPTH_IMPACT_HYBRID_X | DIMENSIONAL_IMPACT_MOVE | Purple | INSERT_SAFE |
| 25 | PARALLAX | DIMENSIONAL_IMPACT_MOVE | Purple | BUS_PREFERRED |
| 26 | NSR | DIMENSIONAL_IMPACT_MOVE | Purple | BUS_PREFERRED |
| 27 | NTRSTLLR | FX_SPATIAL | Purple | BUS_PREFERRED |
| 28 | Cathedral | FX_SPATIAL | Purple | BUS_PREFERRED |
| 29 | SacredVerb | FX_SPATIAL | Purple | BUS_PREFERRED |
| 30 | THOTH | HARMONICS_PITCH | Green | INSERT_SAFE |
| 31 | TEHUTI | HARMONICS_PITCH | Green | INSERT_SAFE |
| 32 | AU | HARMONICS_PITCH | Green | INSERT_SAFE |
| 33 | SLOTMACHINE | CREATIVE_TRANSFORM | Red-orange | CREATIVE_TRANSFORM |
| 34 | ARCHAEOLOGIST_X | CREATIVE_TRANSFORM | Red-orange | CREATIVE_TRANSFORM |
| 35 | SERQET | CREATIVE_TRANSFORM | Red-orange | CREATIVE_TRANSFORM |
| 36 | ANKH | MASTERING_CORE | Silver | MASTER_FIELD |
| 37 | SPHYNX | MASTERING_CORE | Silver | MIX_BUS |
| 38 | MAAT | MASTERING_CORE | Silver | MIX_BUS |
| 39 | HORIZON_X | MASTERING_CORE | Silver | MIX_BUS |
| 40 | PLATINUM | MASTERING_CORE | Silver | MIX_BUS |
| 41 | IMHOTEP | MASTER_FIELD | Silver | MASTER_FIELD |
| 42 | SESHAT | UTILITY_OBSERVATION | Green | OBSERVATION |

## Maintenance Rule

When a plugin's family, color, or Smart Position class changes in `CURRENT_FAMILY_AUTHORITY.md` or `SMART_POSITION_MANIFEST.json`, update that plugin's row here in the same pass. This file should never drift ahead of or behind those two authority files.
