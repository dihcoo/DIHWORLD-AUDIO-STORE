# DIHWorld Audio - 7 Main Bus Template

Drums | Bass | Vocal | Instrument | Effects | Color | Dynamics -> Master  
Enhanced: 2026-07-25

User authority: `DIHWorld_Audio_Complete_Manual_CURRENT.pdf`

Current product behavior: ANUBIS has a named stereo Sidechain bus with separate Key/Duck functions; DEBO uses the balanced canonical bank; TRIPLER uses the repaired clean left/right harmony path; SESHAT named views hide unrelated panels; AU and Drum Morpher are current registered instruments.

Use this as the main multitrack routing template. Each source track feeds one musical family bus; optional parallel buses add effects, color, or dynamics without overloading individual tracks.

## Core Operating Law

- Start buses and sends around -18 dB as a safe audition point, not a fixed operating target.
- In normal use, many DIH processors will feel optimal around -14 to -10 dB, depending on source, family, and FieldState.
- Some plugins operate cleanly at unity when the use case supports it; approve unity only after bypass/output matching and no clipping, ringing, or level jump.
- Output-match to bypass before approving tone, width, spatial placement, or loudness.
- Use up to three active processors on a track or bus. More than three is an audition rack, not a committed mix chain.
- SESHAT is observation only and may sit last on the print/master endpoint.
- Presets never control Input, Output, Mix, Bypass, or protected ceiling/safety controls.
- Keep each plugin in its primary family when possible; if moved, it replaces a slot instead of extending the chain.
- SLOTMACHINE is always last in any chain that uses it. ANKH is the containment authority.


## Architecture

```text
Kick, Snare, OH, Room      -> DRUMS BUS
Bass DI, Sub              -> BASS BUS
Lead Vox, BG Vox          -> VOCAL BUS
Guitars, Keys, Synths     -> INSTRUMENT BUS
FX sends                  -> EFFECTS BUS
Color sends               -> COLOR BUS
Parallel compression      -> DYNAMICS BUS

All seven buses -> PRINT / MASTER BUS -> Stereo Out
```

## Seven Bus Working Chains

| Bus | Receives | Three-active starter chain | Best substitutions |
| --- | --- | --- | --- |
| DRUMS | Kick, snare, rooms, percussion | ANUBIS -> DIH_DRUM_MORPHER -> BALLPARK | DRUMKRUSHGLUE replaces ANUBIS or BALLPARK when the bus needs glue more than guard. |
| BASS | Bass DI, sub, low-end instruments | MARIANA -> NTRPL -> MONOLITH | DEPTH_BOOST_PRO replaces MONOLITH for definition. Do not add sub just because the plugin name says boost. |
| VOCAL | Lead, backgrounds, harmonies | GOLD -> AEGIS_NOVA -> SILVER | WPR replaces SILVER for ribbon warmth. TRIPLER is BG/harmony only. EchoLocate replaces the third slot for localization. |
| INSTRUMENT | Guitars, keys, piano, synths | KHEPRI -> PTAHTUBE -> APIS | THOTH or TEHUTI replaces a color slot when harmonic pitch is the real problem. |
| EFFECTS | FX returns and spatial sends | NTRSTLLR -> Cathedral -> SacredVerb | Do not stack PARALLAX here if a WIDTH bus exists; use the WIDTH bus. |
| COLOR | Vocal and instrument color sends | KHEPRI -> PTAHTUBE -> APIS | SOVEREIGN replaces one color slot for stronger bus color. PLATINUM belongs to Mastering Core with secondary color support. |
| DYNAMICS | Parallel dynamics send | OTIS -> DEBO -> LOOKOUT | SPHYNX belongs on the print/master chain unless this bus is acting as mix-bus preparation. |

## Print / Master Choices

| Use case | Active chain | When |
| --- | --- | --- |
| Clean | SPHYNX -> MAAT -> ANKH -> SESHAT | Prepare, balance, contain, then observe. |
| Authority | PLATINUM -> IMHOTEP -> ANKH -> SESHAT | Master authority plus macro field structure. |
| Loud / modern | SPHYNX -> HORIZON_X -> ANKH -> SESHAT | Lift and finish before containment. |
| Dimensional | DEPTH_IMPACT_HYBRID_X -> MAAT -> ANKH -> SESHAT | Front/back placement before balance and containment. |
| Color master | KHEPRI or SOVEREIGN -> MAAT -> ANKH -> SESHAT | One color stage, one balance stage, then containment. |

## Routing Rules

- Seven buses are enough for this formation. New auxes require a written reason in the deployment register.
- Family buses may receive up to three active inserts; source tracks should usually carry zero to two.
- Use COLOR and EFFECTS buses for parallel tone and space instead of building long chains on every track.
- If a plugin is used outside its home family, document it as a replacement: source problem, chosen substitute, and bypass-matched result.
