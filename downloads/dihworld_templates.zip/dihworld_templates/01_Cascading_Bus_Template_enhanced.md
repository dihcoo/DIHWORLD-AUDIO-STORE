# DIHWorld Audio - Cascading Effects Bus Template

Effects -> Width -> Color -> Collection -> Master | Enhanced for ANKH family placement  
Enhanced: 2026-07-25

User authority: `DIHWorld_Audio_Complete_Manual_CURRENT.pdf`

Current product behavior: ANUBIS has a named stereo Sidechain bus with separate Key/Duck functions; DEBO uses the balanced canonical bank; TRIPLER uses the repaired clean left/right harmony path; SESHAT named views hide unrelated panels; AU and Drum Morpher are current registered instruments.

Use this when a session needs three deliberate parallel lanes feeding one clean collection point. The buses carry the work; source tracks stay lean.

## Core Operating Law

- Start buses and sends around -18 dB as a safe audition point, not a fixed operating target.
- In normal use, many DIH processors will feel optimal around -14 to -10 dB, depending on source, family, and FieldState.
- Some plugins operate cleanly at unity when the use case supports it; approve unity only after bypass/output matching and no clipping, ringing, or level jump.
- Output-match to bypass before approving tone, width, spatial placement, or loudness.
- Use up to three active processors on a track or bus. More than three is an audition rack, not a committed mix chain.
- SESHAT is observation only and may sit last on the print/master endpoint.
- Presets never control Input, Output, Mix, Bypass, or protected ceiling/safety controls.
- Keep each plugin in its primary family when possible; if moved, it replaces a slot instead of extending the chain.
- SLOTMACHINE is always last in any chain that uses it. ANKH is the containment authority.


## Architecture

```text
SOURCE TRACKS
  Send 1 start -18 dB -> EFFECTS BUS [FX_SPATIAL]
  Send 2 start -18 dB -> WIDTH BUS   [DIMENSIONAL_IMPACT_MOVE]
  Send 3 start -18 dB -> COLOR BUS   [COLOR_AMP_TAPE]
  Optimize commonly toward -14 to -10 dB; unity is valid only when clean.

EFFECTS BUS + WIDTH BUS + COLOR BUS
  -> COLLECTION CHANNEL              [no inserts, summing only]
  -> PRINT / MASTER BUS
  -> Stereo Out
```

## Bus Chains

| Bus | Three-active starter chain | Substitutions / notes |
| --- | --- | --- |
| EFFECTS BUS | NTRSTLLR -> Cathedral -> SacredVerb | All three are FX_SPATIAL and bus preferred. Keep reverbs here, not as random track inserts. |
| WIDTH BUS | DEPTH_IMPACT_HYBRID_X -> PARALLAX -> NSR | SERQET replaces PARALLAX for a creative width move; it does not extend the chain. Mono-check before print. |
| COLOR BUS | KHEPRI -> PTAHTUBE -> APIS | SOVEREIGN replaces one color slot when the whole bus needs stronger color authority. PLATINUM is Mastering Core with secondary color support, not a primary Color insert. |
| COLLECTION | No inserts | Collection is a summing point only. If it needs tone, the tone belongs on a lane above or the print bus below. |

## Print / Master Choices

| Use case | Active chain | When |
| --- | --- | --- |
| Clean | SPHYNX -> MAAT -> ANKH -> SESHAT | Prepare, balance, contain, then observe. |
| Authority | PLATINUM -> IMHOTEP -> ANKH -> SESHAT | Master authority plus macro field structure. |
| Loud / modern | SPHYNX -> HORIZON_X -> ANKH -> SESHAT | Lift and finish before containment. |
| Dimensional | DEPTH_IMPACT_HYBRID_X -> MAAT -> ANKH -> SESHAT | Front/back placement before balance and containment. |
| Color master | KHEPRI or SOVEREIGN -> MAAT -> ANKH -> SESHAT | One color stage, one balance stage, then containment. |

## Send Discipline

| From | To | Level | Rule |
| --- | --- | --- | --- |
| Every source track | EFFECTS BUS | Start -18; -14 to -10 usual; unity clean | Spatial material only. Do not hide color or dynamics here. |
| Every source track | WIDTH BUS | Start -18; -14 to -10 usual; unity clean | Width/depth moves only. Collapse-check before printing. |
| Every source track | COLOR BUS | Start -18; -14 to -10 usual; unity clean | Harmonic color lane. Pick three active processors maximum. |
| All buses | COLLECTION | unity route | No inserts on collection. |

## Output Approval

- Match the delivery specification for the project or platform; this template does not impose a fixed RMS, peak, or crest target.
- Preserve musical dynamics and confirm zero unintended clipping.
- Compare at matched loudness before approving the print.
