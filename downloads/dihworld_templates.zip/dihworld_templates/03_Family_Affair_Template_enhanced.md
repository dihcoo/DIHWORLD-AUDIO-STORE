# DIHWorld Audio - FAMILY AFFAIR Use Case Demo Template

One-session Logic demo featuring all 42 plugins  
Enhanced: 2026-07-25

User authority: `DIHWorld_Audio_Complete_Manual_CURRENT.pdf`

Current product behavior: ANUBIS has a named stereo Sidechain bus with separate Key/Duck functions; DEBO uses the balanced canonical bank; TRIPLER uses the repaired clean left/right harmony path; SESHAT named views hide unrelated panels; AU and Drum Morpher are current registered instruments.

This template turns the full DIHWorld Audio suite into one clear family demo. It is not a permission slip to stack every processor on a record. Every plugin appears in the session, but each lane stays organized by family, and the demo moves through the families one scene at a time.

## Core Operating Law

- Start buses and sends around -18 dB as a safe audition point, not a fixed operating target.
- In normal use, many DIH processors will feel optimal around -14 to -10 dB, depending on source, family, and FieldState.
- Output-match to bypass before approving tone, width, spatial placement, or loudness.
- Use up to three active processors on a track or bus. Extra plugins in this template are demo alternates, bypassed slots, or scene-based reveals.
- Keep each plugin in its primary family when possible. If moved, it replaces a slot instead of extending the chain.
- SLOTMACHINE is always last in any chain that uses it. ANKH is the containment authority.
- SESHAT is observation only and may sit last on the print/master endpoint.
- Presets never control protected Input, Output, Mix, Bypass/Power, or final ceiling/safety controls unless a plugin-specific canon explicitly makes that control part of the musical engine.

## Use Case

Build one Logic session around a full-song reference or stem set. The listener hears the raw source first, then each DIHWorld family enters in order: drums, bass, vocals, instruments, effects, color, width, dynamics, creative transform, harmonic pitch, field balance, master structure, and observation.

The goal is to show the system as a family, not to compare it to outside brands. The proof is organized placement: each plugin has a job, a family home, and a moment in the demo.

## Template Lane Order

| Lane | Purpose | Starter chain | Demo note |
| --- | --- | --- | --- |
| DRUM | Drum identity and punch | Drum Morpher -> Ballpark -> DrumKrushGlue | Add ANUBIS only if transient guard is needed. |
| BASS | Foundation and low-end shape | MARIANA -> NTRPL -> MONOLITH | DEPTH_BOOST_PRO is the definition/weight reveal. |
| VOCAL | Lead and stack source tone | GOLD -> AegisNova -> SILVER | WPR, TRIPLER, and EchoLocate show alternates and BG movement. |
| INSTRUMENT | Music bed, keys, guitars, synths | Khepri Sacred Tape Machine -> PtahTube -> APIS | Swap in Thoth, TEHUTI, or AU when harmonic pitch is the point. |
| EFFECTS | Space and reverb returns | NTRSTLLR -> Cathedral -> SacredVerb | Spatial lane only. Keep color and dynamics elsewhere. |
| COLOR | Parallel color and amp/tape authority | Khepri Sacred Tape Machine -> PtahTube -> APIS | SOVEREIGN replaces one slot for stronger bus color. |
| WIDTH | Field width and dimensional movement | Depth Impact Hybrid X -> PARALLAX -> NSR | SERQET replaces PARALLAX for a creative width reveal; it does not extend the chain. |
| DYNAMICS | Parallel protection and movement | OTIS -> DeBo -> LookOut | ANUBIS and DrumKrushGlue enter where the source needs guard/glue. |
| CREATIVE | One special moment, not the whole mix | ARCHAEOLOGIST X -> SERQET -> SlotMachine | SlotMachine stays last. |
| MASTER BUS | Three-stage print chain | SPHYNX -> Maat -> ANKH -> SESHAT | PLATINUM, IMHOTEP, or Horizon X appear as bypassed alternates and replace a stage for their scene. |

## Demo Timeline

| Section | Action | Families featured |
| --- | --- | --- |
| Bars 1-16 | Raw source, no DIH processing. | None; establish the before picture. |
| Bars 17-32 | Bring in DRUM and BASS lanes. | DRUM_INSTRUMENT, BASS_LOW_END, selected DYNAMICS_GUARD. |
| Bars 33-48 | Bring in VOCAL and INSTRUMENT lanes. | VOCAL_MIC_SOURCE, COLOR_AMP_TAPE, HARMONICS_PITCH. |
| Bars 49-64 | Open EFFECTS and WIDTH sends. | FX_SPATIAL, DIMENSIONAL_IMPACT_MOVE, SERQET as width reveal. |
| Bars 65-80 | Add COLOR and CREATIVE moments. | COLOR_AMP_TAPE, CREATIVE_TRANSFORM, FIELD_TONE_BALANCE. |
| Bars 81-96 | Engage MASTER BUS clean chain. | MASTERING_CORE, MASTER_FIELD, UTILITY_OBSERVATION. |
| Bars 97-112 | Print loud/modern reveal, then bypass-match. | HORIZON_X lift, ANKH containment, SESHAT confirmation. |

## All 42 Plugin Coverage

| Primary family | Count | Plugins |
| --- | ---: | --- |
| VOCAL_MIC_SOURCE | 6 | GOLD, SILVER, WPR, AegisNova, TRIPLER, EchoLocate |
| DYNAMICS_GUARD | 4 | ANUBIS, OTIS, DeBo, LookOut |
| BASS_LOW_END | 4 | MARIANA, MONOLITH, DEPTH_BOOST_PRO, NTRPL |
| DRUM_INSTRUMENT | 3 | Drum Morpher, Ballpark, DrumKrushGlue |
| COLOR_AMP_TAPE | 4 | APIS, PtahTube, Khepri Sacred Tape Machine, SOVEREIGN |
| FIELD_TONE_BALANCE | 2 | AUSET, AUSAR |
| DIMENSIONAL_IMPACT_MOVE | 3 | Depth Impact Hybrid X, PARALLAX, NSR |
| FX_SPATIAL | 3 | NTRSTLLR, Cathedral, SacredVerb |
| HARMONICS_PITCH | 3 | Thoth, TEHUTI, AU |
| CREATIVE_TRANSFORM | 3 | SlotMachine, ARCHAEOLOGIST X, SERQET |
| MASTERING_CORE | 5 | ANKH, SPHYNX, Maat, Horizon X, PLATINUM |
| MASTER_FIELD | 1 | IMHOTEP |
| UTILITY_OBSERVATION | 1 | SESHAT |

## Print Checklist

- Every plugin appears at least once in the session.
- No source track or bus has more than three active processors during a musical pass.
- Extra plugins are labeled as BYPASSED ALT, SCENE REVEAL, or QC ONLY.
- SESHAT is last and observation only.
- Match the project delivery specification; this template does not impose fixed RMS, peak, or crest targets. Confirm zero unintended clipping.
- Save two versions: `FAMILY_AFFAIR_TEMPLATE.logicx` and `FAMILY_AFFAIR_DEMO_PRINT.wav`.
