# DIHWorld Audio - Better Buses Template

Customer-safe Logic bus starters | Current ANKH families | Website template 4  
Enhanced: 2026-07-25

User authority: `DIHWorld_Audio_Complete_Manual_CURRENT.pdf`

Current product behavior: ANUBIS has a named stereo Sidechain bus with separate Key/Duck functions; DEBO uses the balanced canonical bank; TRIPLER uses the repaired clean left/right harmony path; SESHAT named views hide unrelated panels; AU and Drum Morpher are current registered instruments.

Use this when you want a cleaner Logic mixer layout with descriptive bus names, short chains, and clear family placement. It is the practical companion to the 7 Main Bus Template: fewer mystery buses, fewer stacked inserts, and easier handoff to another mixer.

## Core Operating Law

- Start buses and sends around -18 dB as a safe audition point, not a fixed operating target.
- In normal use, many DIH processors will feel optimal around -14 to -10 dB, depending on source, family, and FieldState.
- Some plugins operate cleanly at unity when the use case supports it; approve unity only after bypass/output matching and no clipping, ringing, or level jump.
- Output-match to bypass before approving tone, width, spatial placement, or loudness.
- Keep source tracks lean. Use buses for color, space, width, dynamics, and print decisions.
- Use up to three active processors on a source track or bus during a musical pass. Extra inserts are audition alternates, not the committed chain.
- SESHAT is observation only and may sit last on the print/master endpoint.
- ANKH is the final containment authority.

## Better Bus Architecture

```text
SOURCE TRACKS
  -> DRUM BUS
  -> BASS BUS
  -> LEAD VOCAL BUS
  -> BG VOCAL BUS
  -> INSTRUMENT BUS
  -> optional sends: FX BUS, COLOR BUS, WIDTH BUS, DYNAMICS BUS

FAMILY BUSES
  -> PRINT / MASTER BUS
  -> Stereo Out
```

## Customer Bus Starters

| Bus | Three-active starter | Best use | Notes |
| --- | --- | --- | --- |
| LEAD VOCAL BUS | GOLD -> AEGIS_NOVA -> SILVER | Lead vocal source tone and protection | Use WPR instead of SILVER when ribbon warmth is the goal. |
| BG VOCAL BUS | GOLD -> TRIPLER -> EchoLocate | Stacks, doubles, localization | Keep lead diction clear; do not force TRIPLER on every lead. |
| DRUM BUS | DIH_DRUM_MORPHER -> BALLPARK -> DRUMKRUSHGLUE | Drum identity, punch, and glue | Use ANUBIS before the bus when individual transient guard is needed. |
| BASS BUS | MARIANA -> NTRPL -> MONOLITH | Low-end focus and foundation | DEPTH_BOOST_PRO can replace MONOLITH for definition. |
| INSTRUMENT BUS | KHEPRI -> PTAHTUBE -> APIS | Music-bed tone, body, and harmonic color | THOTH or TEHUTI replaces a color slot when harmonic pitch is the actual problem. |
| FX BUS | NTRSTLLR -> Cathedral -> SacredVerb | Shared spatial identity and room field | Keep reverbs here instead of scattering long tails across source tracks. |
| COLOR BUS | KHEPRI -> PTAHTUBE -> APIS | Parallel tone and bus color | SOVEREIGN replaces one slot for stronger color authority. |
| WIDTH BUS | DEPTH_IMPACT_HYBRID_X -> PARALLAX -> NSR | Width, placement, and front/back movement | SERQET can replace PARALLAX for a creative width move. Mono-check before print. |
| DYNAMICS BUS | ANUBIS -> OTIS -> DEBO | Parallel guard and movement | LOOKOUT may observe. DRUMKRUSHGLUE belongs on drum glue when needed. |

## Print / Master Bus Choices

| Goal | Chain | When |
| --- | --- | --- |
| Clean print | SPHYNX -> MAAT -> ANKH -> SESHAT | Prepare, balance, contain, then observe. |
| Authority print | PLATINUM -> IMHOTEP -> ANKH -> SESHAT | Master authority plus macro field structure. |
| Loud / modern print | SPHYNX -> HORIZON_X -> ANKH -> SESHAT | Lift and finish without replacing ANKH. |
| Dimensional print | DEPTH_IMPACT_HYBRID_X -> MAAT -> ANKH -> SESHAT | Front/back placement before balance and containment. |
| Color master | KHEPRI or SOVEREIGN -> MAAT -> ANKH -> SESHAT | One color stage, one balance stage, then containment. |

## Handoff Labels

| Label | Meaning |
| --- | --- |
| ACTIVE | Processor is part of the current musical pass. |
| BYPASSED ALT | Processor is present as a documented alternate, not active. |
| QC ONLY | Observation, metering, or validation only. |
| PRINT CHAIN | Final chain chosen for the bounce. |

## Approval Checklist

- Every bus has a clear musical reason.
- No source track is carrying a long chain that belongs on a family bus.
- COLOR, FX, WIDTH, and DYNAMICS are sends or parallel buses, not hidden source-track clutter.
- SESHAT is observation only.
- ANKH remains final containment authority.
- The final print is bypass/output matched before approval.
